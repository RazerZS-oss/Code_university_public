import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class BBM {
  final String nama;
  final double harga;

  BBM({required this.nama, required this.harga});

  @override
  String toString() {
    return nama;
  }
}

class MainApp extends StatelessWidget {
  const MainApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: "Kalkulator BBM",
      home: MainHomePage(),
    );
  }
}

class MainHomePage extends StatefulWidget {
  const MainHomePage({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _MainHomePage();
}

class _MainHomePage extends State<MainHomePage> {
  var listBbm = <BBM>[
    BBM(nama: 'Premium', harga: 10000),
    BBM(nama: 'Pertamax', harga: 14000),
    BBM(nama: 'Pertamax Turbo', harga: 16600),
    BBM(nama: 'Solar', harga: 6800),
  ];

  var listKendaraan = ['Avanza', 'Xenia', 'Sigra', 'Brio'];

  TextEditingController tujuanCtrl = TextEditingController();
  TextEditingController jarakCtrl = TextEditingController();
  String textHasil = '';
  BBM? selectedBBM;
  String selectedKendaraan = '';

  @override
  void initState() {
    super.initState();
    selectedBBM = listBbm[0];
    selectedKendaraan = listKendaraan[0];
  }

  void setHasil() {
    double rasio = 0.0;

    // Mengambil rasio konsumsi BBM sesuai dengan pilihan kendaraan
    switch (selectedKendaraan) {
      case 'Avanza':
        rasio = 10.0;
        break;
      case 'Xenia':
        rasio = 12.0;
        break;
      case 'Sigra':
        rasio = 15.0;
        break;
      case 'Brio':
        rasio = 14.0;
        break;
    }

    double biaya = selectedBBM!.harga * (double.parse(jarakCtrl.text) / rasio);

    setState(() {
      textHasil = 'Biaya BBM: Rp ${biaya.toStringAsFixed(2)}';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Kalkulator BBM"),
      ),
      body: Padding(
        padding: const EdgeInsets.only(left: 20, right: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              margin: const EdgeInsets.only(top: 40, bottom: 30),
              child: const Center(
                child: Text(
                  'Hitung BBM & Biaya',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            const Text("Nama Tujuan"),
            TextField(controller: tujuanCtrl),
            const SizedBox(height: 20),
            const Text("Jarak Tempuh"),
            TextField(controller: jarakCtrl),
            const SizedBox(height: 20),
            const Text("Pilihan BBM"),
            DropdownButton<BBM>(
                isExpanded: true,
                value: selectedBBM,
                items: listBbm.map((BBM item) {
                  return DropdownMenuItem<BBM>(
                      value: item, child: Text(item.toString()));
                }).toList(),
                onChanged: (BBM? newVal) {
                  setState(() {
                    selectedBBM = newVal;
                  });
                }),
            const SizedBox(height: 20),
            const Text("Pilihan Kendaraan"),
            DropdownButton<String>(
              isExpanded: true,
              value: selectedKendaraan,
              items: listKendaraan.map((String item) {
                return DropdownMenuItem<String>(
                  value: item,
                  child: Text(item),
                );
              }).toList(),
              onChanged: (String? newVal) {
                setState(() {
                  selectedKendaraan = newVal!;
                });
              },
            ),
            SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                    onPressed: setHasil, child: const Text("Hitung BBM"))),
            const SizedBox(height: 20),
            Text(textHasil),
          ],
        ),
      ),
    );
  }
}
