import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: RestaurantProfile(),
    );
  }
}

class RestaurantProfile extends StatelessWidget {
  final String email = '111202214629@mhs.dinus.ac.id';
  final String phoneNumber = '+62 81325354847';
  final double latitude = -6.980957;
  final double longitude = 110.406811;

  void launchEmail() async {
    final Uri uri = Uri(
      scheme: 'mailto',
      path: email,
      queryParameters: {'subject': 'Tanya Seputar Resto'},
    );
    if (await canLaunch(uri.toString())) {
      await launch(uri.toString());
    }
  }

  void makePhoneCall() async {
    final Uri uri = Uri(scheme: 'tel', path: phoneNumber);
    if (await canLaunch(uri.toString())) {
      await launch(uri.toString());
    }
  }

  void openMap() async {
    final Uri uri = Uri(
      scheme: 'https',
      host: 'www.google.com',
      path: '/maps/search/',
      queryParameters: {'api': '1', 'query': '$latitude,$longitude'},
    );
    if (await canLaunch(uri.toString())) {
      await launch(uri.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profil Restoran'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Icon(
                Icons.restaurant,
                size: 60,
                color: Colors.blue,
              ),
              SizedBox(height: 16),
              Text(
                'RM. Sedap Rasa',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Image.asset(
                'assets/restoHOME.jpg',
                width: 120,
                height: 120,
              ),
              SizedBox(height: 32),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  IconButton(
                    icon: Icon(Icons.email),
                    onPressed: () {
                      launchEmail();
                    },
                  ),
                  IconButton(
                    icon: Icon(Icons.phone),
                    onPressed: () {
                      makePhoneCall();
                    },
                  ),
                  IconButton(
                    icon: Icon(Icons.map),
                    onPressed: () {
                      openMap();
                    },
                  ),
                ],
              ),
              SizedBox(height: 32),
              Text(
                'Menu Restoran',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Expanded(
                child: ListView(
                  children: <Widget>[
                    ListTile(
                      title: Text('Nasi Goreng'),
                      subtitle: Text('Nasi goreng dengan telur dan ayam'),
                    ),
                    ListTile(
                      title: Text('Mie Goreng'),
                      subtitle: Text('Mie goreng spesial dengan bumbu khas'),
                    ),
                    ListTile(
                      title: Text('Sate Ayam'),
                      subtitle: Text('Sate ayam dengan bumbu kacang lezat'),
                    ),
                    // Tambahkan daftar menu lainnya sesuai kebutuhan
                  ],
                ),
              ),
              SizedBox(height: 32),
              // Tambahkan bagian alamat di bawah menu
              Text(
                'Alamat Restoran',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text(
                'Jl. Udinus Semarang',
                style: TextStyle(fontSize: 16),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 16),
              // Tambahkan bagian jadwal buka
              Text(
                'Jadwal Buka',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text(
                'Senin - Sabtu: 08.00 - 22.00\nMinggu: 10.00 - 20.00',
                style: TextStyle(fontSize: 16),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
